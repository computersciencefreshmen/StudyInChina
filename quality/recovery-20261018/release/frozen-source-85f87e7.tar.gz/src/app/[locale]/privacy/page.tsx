import { notFound } from 'next/navigation'
import { PolicyPage } from '@/components/features/PolicyPage'
import { getMessages } from '@/i18n/messages'
import { getCityMapPrivacy } from '@/i18n/city-map'
import { pageMetadata, requireLocale } from '@/lib/site'
import { getNotificationPrivacy } from '@/lib/site-notifications'

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const locale = requireLocale((await params).locale) || 'en'
  const copy = getMessages(locale).legal.privacy
  return pageMetadata(locale, copy.title, copy.intro, 'privacy')
}

export default async function PrivacyPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = requireLocale((await params).locale)
  if (!locale) notFound()
  const copy = getMessages(locale).legal.privacy
  return <PolicyPage locale={locale} eyebrow={copy.eyebrow} title={copy.title} intro={copy.intro} sections={[...copy.sections, getCityMapPrivacy(locale), getNotificationPrivacy(locale)]} />
}
